import java.text.SimpleDateFormat;
import java.util.Date;

public class DateToString {

    public static void main(String[] args) {
    
        Date date = new Date();
        System.out.println("Before formatting: " + date);

        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        String formatted = formatter.format(date);
        System.out.println("After formatting: " + formatted);
    }
}
